package com.test.cameraplugin;

import android.annotation.SuppressLint;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;

import com.unity3d.player.UnityPlayer;

@SuppressLint("NewApi")
public class PluginActivity extends Fragment {
    private Context mContext;
    private static final String TAG = "MyPlugin";
    public static PluginActivity _instance;
    public static PluginActivity GetInstance(){
        if(_instance == null){
            _instance = new PluginActivity();
            UnityPlayer.currentActivity.getFragmentManager().beginTransaction().add(_instance,TAG).commit();
        }
        return _instance;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    //Unity中会调用这个方法，用于区分打开摄像机 开始本地相册
    @SuppressLint({"NewApi"})
    public void TakePhoto(String str, String gameObjectName)
    {
        Log.d(TAG, "TakePhoto: ");
        if (_instance.getContext()!=null){
            Log.d(TAG, "TakePhoto: getContext");
        }
        Intent intent = new Intent(mContext, WebViewActivity.class);
        intent.putExtra("type", str);
        intent.putExtra("gameobject", gameObjectName);
        startActivity(intent);
    }
}

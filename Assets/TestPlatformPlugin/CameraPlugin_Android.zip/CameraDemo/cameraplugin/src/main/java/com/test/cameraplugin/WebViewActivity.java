package com.test.cameraplugin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import com.unity3d.player.UnityPlayer;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WebViewActivity extends Activity
{
    public static final int NONE = 0;
    public static final int PHOTOHRAPH = 1;
    public static final int PHOTOZOOM = 2;
    public static final int PHOTORESOULT = 3;
    public static final String IMAGE_UNSPECIFIED = "image/*";
    public static String fileName;
    private Uri imageUri;
    public static File tempFile;
    public static String gameobject;

    @SuppressLint({"SimpleDateFormat"})
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        String type = getIntent().getStringExtra("type");
        gameobject = getIntent().getStringExtra("gameobject");

        if (type.equals("takePhoto")) {
            int currentapiVersion = Build.VERSION.SDK_INT;
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            if (hasSdcard()) {
                SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
                String filename = timeStampFormat.format(new Date());
                tempFile = new File(Environment.getExternalStorageDirectory(), filename + ".jpg");
                if (currentapiVersion < 24)
                {
                    this.imageUri = Uri.fromFile(tempFile);
                    intent.putExtra("output", this.imageUri);
                }
                else {
                    ContentValues contentValues = new ContentValues(1);
                    contentValues.put("_data", tempFile.getAbsolutePath());

                    this.imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                    intent.putExtra("output", this.imageUri);
                }
                startActivityForResult(intent, 1);
            }
        } else {
            Intent intent = new Intent("android.intent.action.PICK", null);
            intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
            startActivityForResult(intent, 2);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (resultCode == 0) {
            finish();
            return;
        }

        if (requestCode == 1)
        {
            startPhotoZoom(this.imageUri);
        }
        if (data == null) {
            return;
        }
        if (requestCode == 2) {
            startPhotoZoom(data.getData());
        }

        if (requestCode == 3) {
            Bundle extras = data.getExtras();
            if (extras != null) {
                Bitmap photo = (Bitmap)extras.getParcelable("data");
                try
                {
                    SaveBitmap(photo);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void startPhotoZoom(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");

        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);

        intent.putExtra("outputX", 300);
        intent.putExtra("outputY", 300);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 3);
    }
    @SuppressLint({"SdCardPath", "SimpleDateFormat"})
    public void SaveBitmap(Bitmap bitmap) throws IOException {
        FileOutputStream fOut = null;
        String path = Environment.getExternalStorageDirectory() + "/Android/data/com.supergenius.sudokuapp/files/avatar";
        SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
        String filename = timeStampFormat.format(new Date()) + ".jpg";
        try
        {
            File destDir = new File(path);
            if (!destDir.exists()) {
                destDir.mkdirs();
            }
            fOut = new FileOutputStream(path + "/" + filename);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
        try {
            fOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fOut.close();
            finish();
            UnityPlayer.UnitySendMessage(gameobject, "message", path + "/" + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean hasSdcard() {
        return Environment.getExternalStorageState().equals("mounted");
    }
}

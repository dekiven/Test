package com.test.mylibrary;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;

import com.unity3d.player.UnityPlayer;

public class MainActivity extends Fragment {

    private static final String TAG = "MyPlugin";
    public static MainActivity _instance;
    public static MainActivity GetInstance(){
        if(_instance == null){
            _instance = new MainActivity();
            UnityPlayer.currentActivity.getFragmentManager().beginTransaction().add(_instance,TAG).commit();
        }
        return _instance;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    //Unity中会调用这个方法，用于区分打开摄像机 开始本地相册
    @SuppressLint({"NewApi"})
    public void TakePhoto(String str, String gameObjectName)
    {
        Intent intent = new Intent(_instance.getContext(), WebViewActivity.class);
        intent.putExtra("type", str);
        intent.putExtra("gameobject", gameObjectName);
        startActivity(intent);
    }
}

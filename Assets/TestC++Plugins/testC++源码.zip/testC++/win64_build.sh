#!/bin/bash
# 64 Bit Version
mkdir -p window/x86_64
cd ./src
gcc -m64 -O2 -shared \
	test.c \
	testCPP.cpp \
	-o ../window/x86_64/test_lib.dll \
	-Wl,--no-whole-archive -static-libgcc -static-libstdc++

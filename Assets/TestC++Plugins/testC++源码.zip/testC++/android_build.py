# -*- coding:utf-8 -*-
import os
from DKVTools.Funcs import *

ndkRoot = '/Users/sjytyf3/Documents/android-ndk-r10e'
curDir = os.getcwd()

androidDir = pathJoin(curDir, 'android')
print(androidDir)
os.chdir(androidDir)

addTempPathForOs(ndkRoot)

rst = tryCmd('ndk-build')
for r in rst :
	print(r.decode('GBK').encode('utf-8'))

copyTree(pathJoin(androidDir, 'libs'), pathJoin(curDir, 'Plugins/Android/libs'))
# print(rst)
i = input()
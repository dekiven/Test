#!/bin/bash
# 32 Bit Version
mkdir -p window/x86
cd ./src
gcc -m32 -O2 -shared \
	test.c \
	testCPP.cpp \
	-o ../window/x86/test_lib.dll \
	-Wl,--no-whole-archive -static-libgcc -static-libstdc++

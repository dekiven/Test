#ifndef __Test_h__
#define __Test_h__
#include <stdio.h>

int test(int a, int b);

#endif

#include "test.h"

int test(int a, int b)
{
	return a + b;
}

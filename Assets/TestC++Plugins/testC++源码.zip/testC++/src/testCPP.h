#ifndef __Test_CPP_h__
#define __Test_CPP_h__
// #include <stdio.h>
// #include <string.h>

// #ifdef _cplusplus
extern "C"
{
// #endif    //_cplusplus
	int testCPP(int a, int b);
	bool setString(const char* str);

	
	const char* getString();


	// error 
	// void getStringBuilder(char** str_ptr);
	
// #ifdef _cplusplus
}
// #endif    //_cplusplus

#endif
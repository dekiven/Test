#include "testCPP.h"

// #ifdef _cplusplus
extern "C"
{
// #endif    //_cplusplus

	class TestClass
	{
	public:
		TestClass(){}
		~TestClass(){}

		static int testCPP(int a, int b)
		{
			return a + b;
		}

		const char* getString()
		{
			return "string form TestClass1";
		}
		
	};

	int testCPP(int a, int b)
	{
		return TestClass::testCPP(a, b);
	}

	bool setString(const char* str)
	{
		return str[0] == 's';
	}

	const char* getString()
	{
		TestClass t = TestClass();
		return t.getString();
		// return "111111111 test char*";
	}



	// void getStringBuilder(char** str_ptr)
	// {
	// 	// const char* c = "getStringBuilder";
	// 	// strcpy(*str_ptr, c);
	// }
// #ifdef _cplusplus
}
// #endif    //_cplusplus


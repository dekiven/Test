# -*- coding:utf-8 -*-
import os
import time
from DKVTools.Funcs import *

curDir = os.getcwd()
srcDir = pathJoin(curDir, 'src')
libName = 'test_lib'

srcFiles = []
for _dir, folders, files in os.walk(srcDir) :
	for f in files :
		if os.path.splitext(f)[-1].lower() in ('.c', '.cpp') :
			srcFiles.append(getRelativePath(pathJoin(_dir, f), srcDir)[0])
platforms = ((32, 'x86'), (64, 'x86_64'))
for n, s in platforms :
	targetDir = pathJoin(curDir, 'Plugins/%s'%(s))
	if not os.path.isdir(targetDir) :
		print('make '+targetDir)
		os.makedirs(targetDir)
	sh = '''#!/bin/bash
# %d Bit Version
mkdir -p Plugins/%s
cd ./src
gcc -m%d -O2 -shared \\\n\t%s \\
	-o ../Plugins/%s/%s.dll \\
	-Wl,--no-whole-archive -static-libgcc -static-libstdc++
'''%(n, s, n, ' \\\n\t'.join(srcFiles), s, libName)
	shPath = pathJoin(curDir, 'win%d_build.sh'%(n))
	f = open(shPath, 'w')
	f.write(sh)
	f.close()

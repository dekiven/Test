# -*- coding:utf-8 -*-

import os
from DKVTools.Funcs import *

curDir = os.getcwd()

# dllPath = pathJoin(curDir, 'window')
# copyTree(dllPath, 'C:/Users/Administrator/Desktop/NewProj/Assets/Plugins')
copyTree(pathJoin(curDir, 'Plugins'), '/Users/sjytyf3/Documents/U3DProjs/Test/Assets/Plugins')
# removeTree(dllPath)
#!/usr/bin/env bash

cd ./mac/
xcodebuild clean
xcodebuild -configuration=Release
cp -r build/Release/*.bundle ../Plugins/
